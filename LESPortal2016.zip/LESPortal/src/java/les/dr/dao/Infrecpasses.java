
package les.dr.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;

public class Infrecpasses implements ICollection<Infrecpass>{
    
    @Override
    public boolean add(Infrecpass a) {
        boolean res = false;
        DBConnection mdb = DBConnection.instance();
        Connection cc = mdb.connect();
            if(cc!=null){
               
            Statement st;
            
            try {
                st =cc.createStatement();
                st.executeUpdate("replace into infrecpass "+
                "values('"+a.getemail()+"', '"+a.get_GID()+"', '"+a.get_data()+"');");
                st.close();
                res = true;
            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Infrecpasses.class.getName()).log(Level.SEVERE, null, ex);
            }
                
                
           
            
        }
        return res;
    }

  @Override
    public Infrecpass find(Infrecpass a) {
        Infrecpass res = null;
        DBConnection mdb = DBConnection.instance();
        Connection cc = mdb.connect();
        if (cc != null) {
            try {
                Statement st;
                st = cc.createStatement();
                try (ResultSet rs = st.executeQuery("select * from infrecpass"
                        + " where _email='" + a.getemail()+ "';")) {
                    if (rs.first()) {
                        res = new Infrecpass (rs.getString("email"),
                                rs.getString("gid"),
                                rs.getDate("data"));
                    }
                }
                st.close();

            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Infrecpasses.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        return res;
    }

    @Override
    public List<Infrecpass> list() {
        List<Infrecpass> res = new java.util.LinkedList<>();
        Infrecpass t;
        DBConnection mdb = DBConnection.instance();
        Connection cc = mdb.connect();
        if (cc != null) {
            try {
                Statement st;
                st = cc.createStatement();
                try (ResultSet rs = st.executeQuery("select * from infrecpass")) {
                    while (rs.next()){
                        t = new Infrecpass (rs.getString("email"),
                                rs.getString("gid"),
                                rs.getDate("data"));
                        res.add(t);
                    }
                    rs.close();
                    st.close();
                }
                

            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Infrecpasses.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        return res;
    }

    @Override
    public boolean rem(Infrecpass a) {
        boolean res = false;
        DBConnection mdb = DBConnection.instance();
        Connection cc = mdb.connect();
        if (cc != null) {

            Statement st;

            try {
                st = cc.createStatement();
                st.executeUpdate("delete from infrecpass where _email='" + a.getemail()+ "';");
                st.close();
                res = true;
            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Infrecpass.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        return res;
    }
    }

  

