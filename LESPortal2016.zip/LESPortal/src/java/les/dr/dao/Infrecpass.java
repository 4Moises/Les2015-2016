
package les.dr.dao;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Infrecpass {
    
    private String _email;
    private String _GID;
    private Date _data;

    DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
    public Infrecpass(){}
        
    public Infrecpass(String e){_email=e;}
    public Infrecpass( String e, String g, Date d){
        _email=e; _GID=g; _data=d;
    }
   
            
    

    /**
     * @return the _email
     */
    public String getemail() {
        return _email;
    }

    /**
     * @param _email the _email to set
     */
    public void set_email(String _email) {
        this._email = _email;
    }

    /**
     * @return the _GID
     */
    public String get_GID() {
        return _GID;
    }

    /**
     * @param _GID the _GID to set
     */
    public void set_GID(String _GID) {
        this._GID = _GID;
    }

    /**
     * @return the _data
     */
    public Date get_data() {
        return _data;
    }

    /**
     * @param _data the _captcha to set
     */
    public void setdata(Date _data) {
        this._data = _data;
    }

    
}