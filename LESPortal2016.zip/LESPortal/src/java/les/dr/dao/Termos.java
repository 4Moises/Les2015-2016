/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package les.dr.dao;

/**
 *
 * @author Carlos Sampaio
 */
import com.sun.istack.internal.logging.Logger;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;

public class Termos implements ICollection<Termo>{

    @Override
    public boolean add(Termo t) {
        boolean res = false;
        DBConnection mdb = DBConnection.instance();
        Connection cc = mdb.connect();
            if(cc!=null){
               
            Statement st;
            
            try {
                st = cc.createStatement();
                String ss ="replace into termo "+
                        "values('" + t.getid_termo()+"', '" + t.getnome()+"','" + t.getid_alerta()+"');";
                st.executeUpdate(ss);
                st.close();
                res = true;
            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Termos.class.getName()).log(Level.SEVERE, null, ex);
            }
                
                
           
            
        }
        return res;
    }
    public boolean addtermo(Termo t,String Email) {//adicionar termo do alerta
        boolean res = false;
        DBConnection mdb = DBConnection.instance();
        Connection cc = mdb.connect();
            if(cc!=null){
               
            Statement st;
            
            try {
                st = cc.createStatement();
                String ss ="INSERT INTO termo (nome, id_alerta) VALUES ('"+t.getnome()+"', (SELECT MAX(id_alerta) AS id_alerta FROM alerta WHERE email='"+Email+"'));";
                st.executeUpdate(ss);
                st.close();
                res = true;
            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Termos.class.getName()).log(Level.SEVERE, null, ex);
            }
                
                
           
            
        }
        return res;
    }
    

    @Override
    public boolean rem(Termo t) {
        boolean res = false;
        DBConnection mdb = DBConnection.instance();
        Connection cc = mdb.connect();
        if (cc != null) {

            Statement st;

            try {
                st = cc.createStatement();
                st.executeUpdate("delete from Termo where Id_termo='" + t.getid_termo() + "';");
                st.close();
                res = true;
            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Termos.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        return res;
    }

    @Override
    public Termo find(Termo t) {
        Termo res = null;
        DBConnection mdb = DBConnection.instance();
        Connection cc = mdb.connect();
        if (cc != null) {
            try {
                Statement st;
                st = cc.createStatement();
                ResultSet rs = st.executeQuery("select * from termo"
                        + " where Id_termo='" + t.getid_termo() + "';");
                if (rs.first()) {
                    res = new Termo (rs.getInt("id_termo"),
                            rs.getString("Name"),
                            rs.getInt("id_alerta"));
                }
                rs.close();
                st.close();

            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Termos.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        return res;
    }

    @Override
    public List<Termo> list() {
        List<Termo> res = new java.util.LinkedList<Termo>();
        Termo t;
        DBConnection mdb = DBConnection.instance();
        Connection cc = mdb.connect();
        if (cc != null) {
            try {
                Statement st;
                st = cc.createStatement();
                ResultSet rs = st.executeQuery("select * from termo");
                while (rs.next()){
                    t = new Termo (rs.getInt("id_termo"),
                            rs.getString("Name"),
                            rs.getInt("id_alerta"));
                    res.add(t);
                }
                rs.close();
                st.close();

            } catch (SQLException ex) {
                java.util.logging.Logger.getLogger(Termos.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        return res;
    }

}

    

  

