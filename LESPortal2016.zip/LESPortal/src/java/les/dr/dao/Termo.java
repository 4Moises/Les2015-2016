/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package les.dr.dao;

/**
 *
 * @author Carlos Sampaio
 */
public class Termo {
    private int _id_termo;
    private String _nome;
    private int _id_alerta;

    public Termo(){}
    public Termo (int t){_id_termo=t;}
    public Termo (String n){
        
        _nome=n;
               
    }
     public Termo (int i,String n,int ida){
        _id_termo=i;
        _nome=n;
        _id_alerta=ida;
               
    }

    /**
     * @return the _id_termo
     */
    public int getid_termo() {
        return _id_termo;
    }

    /**
     * @param _id_termo the _id_termo to set
     */
    public void setid_termo(int _id_termo) {
        this._id_termo = _id_termo;
    }

    /**
     * @return the _nome
     */
    public String getnome() {
        return _nome;
    }

    /**
     * @param _nome the _name to set
     */
    public void setnome(String _name) {
        this._nome = _nome;
    }

    /**
     * @return the _id_alerta
     */
    public int getid_alerta() {
        return _id_alerta;
    }

    /**
     * @param _id_alerta the _id_alerta to set
     */
    public void setid_alerta(int _id_alerta) {
        this._id_alerta = _id_alerta;
    }
    
}