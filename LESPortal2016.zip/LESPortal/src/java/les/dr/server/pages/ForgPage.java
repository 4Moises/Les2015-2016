/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package les.dr.server.pages;

import java.io.PrintWriter;

/**
 *
 * @author Utilizador
 */
public class ForgPage extends Page {

   private String _msg="";
    
    public ForgPage(PrintWriter o) {
        super(o);
    }

    public ForgPage(PrintWriter o, String msg) {
        super(o);
        _msg=msg;
    }

    @Override
    protected void genTitle() {
       printTab(); out.println("<title>DR -Esqueceu da Pass</title>");
    }
     protected void genCSS(){
        printTab(); out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"logincss.css\"/>");
    }

    @Override
    protected void genBody() {
         out.println("<body>");
        tab++;
        printTab(); out.println(""
                + "<div class=\"container\">\n" +
"    \n" +
"	<section id=\"content\">\n" +
"		<form action=\"forg1\" method=\"POST\">\n" +
"		\n" +
                "<label class=\"control-label col-sm-2\"\">Email" +
"			<div>\n" +
"				<input type=\"text\" required=\"\" name=\"email\" />\n" +
"			</div>\n" +
"                </label>\n"  + 
                "                       <div id=\"ppp\" style=\"color:red\">"+_msg+"</div>\n"+
"			<div>\n" +
"				<input type=\"submit\" value=\"Ok\"/>\n" +
"			</div>\n" +
"		</form><!-- form -->\n" +
"		<div class=\"button\">\n" +
"			<!--<a href=\"#\">Download source file</a> -->\n" +
"		</div><!-- button -->\n" +
"	</section><!-- content -->\n" +
"</div><!-- container -->"
        );
       
        tab--;
        printTab(); out.println("</body>");

    
    }
    
}
