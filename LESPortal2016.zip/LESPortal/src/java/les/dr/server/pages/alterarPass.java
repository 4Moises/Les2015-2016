
package les.dr.server.pages;


import java.io.PrintWriter;
import java.util.List;
import les.dr.dao.Alerta;
import les.dr.dao.Alertas;

/**
 *
 * @author Utilizador
 */
public class alterarPass  extends OPages{

    public alterarPass(PrintWriter o) {
        super(o);
    }

    
    

   
    protected void genTitle() {
         printTab(); out.println("<title>DR - Password</title>");
        }
     protected void genScript(){
          printTab(); out.println("<script src=\"assets/js/envio_alerta.js\"></script>");
     }
     protected void genRightSide(){
          
          printTab(); out.println("<div id=\"content\">\n" +
"				<div class=\"inner\">\n" +
"\n" +
"					<!-- Post -->\n" +
"						<article class=\"box post post-excerpt\">\n" +
"							<header>\n" +
"								<!--\n" +
"									Note: Titles and subtitles will wrap automatically when necessary, so don't worry\n" +
"									if they get too long. You can also remove the <p> entirely if you don't\n" +
"									need a subtitle.\n" +
"								-->\n" +
"								<h2><img src=\"images/DRE.png\" alt=\"\" /></h2>\n" +
"								<!--<p>A free, fully responsive HTML5 site template by HTML5 UP</p>-->\n" +
"							</header>\n" +
"							<div class=\"info\">\n" +
"								<!--\n" +
"									Note: The date should be formatted exactly as it's shown below. In particular, the\n" +
"									\"least significant\" characters of the month should be encapsulated in a <span>\n" +
"									element to denote what gets dropped in 1200px mode (eg. the \"uary\" in \"January\").\n" +
"									Oh, and if you don't need a date for a particular page or post you can simply delete\n" +
"									the entire \"date\" element.\n" +
"\n" +
"								-->\n" +
"								<!--<span class=\"date\"><span class=\"month\">Jul<span>y</span></span> <span class=\"day\">14</span><span class=\"year\">, 2014</span></span>-->\n" +
"								<!--\n" +
"									Note: You can change the number of list items in \"stats\" to whatever you want.\n" +
"								-->\n" +
"								<!--<ul class=\"stats\">\n" +
"									<li><a href=\"#\" class=\"icon fa-comment\">16</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-heart\">32</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-twitter\">64</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-facebook\">128</a></li>\n" +
"								</ul>-->\n" +
"							</div>\n" +
"							 <div class=\"container\">\n" +
"            <div class=\"jumbotron\">\n" +
"                <h2><i class=\"fa fa-gears\"></i>Configuração</h2> \n" +
"            </div>\n" +
"                                                             <br>\n" +
"                                                             <br>\n" +
"                                                             <br>\n" +
"                                                             <br>\n" +
"            <nav class=\"navbar navbar-default\">\n" +
"               \n" +
"\n" +
"            </nav>\n" +
"            <!-- REGISTRATION FORM -->\n" +
"            <div class=\"panel panel-default\">\n" +
"                <div class=\"panel-heading\"></div>\n" +
"                <div class=\"panel-body\">    \n" +
"                    <form class=\"form-horizontal\" role=\"form\" action=\"validarpwd\" method=\"post\">\n" +
"                        \n" +
"                         <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"password\">Password:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"password\" class=\"form-control\" id=\"password\" name=\"password\" placeholder=\"Introduza a password\">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        </div>\n" +
"                         <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"novopassword\">Novo Password:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"password\" class=\"form-control\" id=\"novopassword\" name=\"novopassword\" placeholder=\"Introduza a password\">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"pwd\">Confirmar Password:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"password\" class=\"form-control\" id=\"confirmacaopassword\" name=\"confirmacaopassword\" placeholder=\"Introduza a password\">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                         \n" +
"                     <br>\n" +
"                                                             <br>\n" +
"                        <div class=\"form-group\">        \n" +
"                            <div class=\"col-sm-offset-2 col-sm-10\">\n" +
"                                <button type=\"submit\" class=\"btn btn-default\" name=\"Submeter\">Submit</button>\n" +
"                            </div>\n" +
"                        </div>\n" +
"<ul id=\"copyright\">\n" +
"						<li>&copy; LesCompany.</li><li>Design: <a href=\"http://html5up.net\">Les 2016</a></li>\n" +
"					</ul>\n" +
"                    </form>\n" +
"                </div>\n" +
"            </div>\n" +
"\n" +
"        </div>\n" +
"						</article>\n" +
"\n" +
"					<!-- Post -->\n" +
"					<!--	<article class=\"box post post-excerpt\">\n" +
"							<header>\n" +
"								<h2><a href=\"#\">Lorem ipsum dolor sit amet</a></h2>\n" +
"								<p>Feugiat interdum sed commodo ipsum consequat dolor nullam metus</p>\n" +
"							</header>\n" +
"							<div class=\"info\">\n" +
"								<span class=\"date\"><span class=\"month\">Jul<span>y</span></span> <span class=\"day\">8</span><span class=\"year\">, 2014</span></span>\n" +
"								<ul class=\"stats\">\n" +
"									<li><a href=\"#\" class=\"icon fa-comment\">16</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-heart\">32</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-twitter\">64</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-facebook\">128</a></li>\n" +
"								</ul>\n" +
"							</div>\n" +
"							<a href=\"#\" class=\"image featured\"><img src=\"images/pic02.jpg\" alt=\"\" /></a>\n" +
"							<p>\n" +
"								Quisque vel sapien sit amet tellus elementum ultricies. Nunc vel orci turpis. Donec id malesuada metus.\n" +
"								Nunc nulla velit, fermentum quis interdum quis, tate etiam commodo lorem ipsum dolor sit amet dolore.\n" +
"								Quisque vel sapien sit amet tellus elementum ultricies. Nunc vel orci turpis. Donec id malesuada metus.\n" +
"								Nunc nulla velit, fermentum quis interdum quis, convallis eu sapien. Integer sed ipsum ante.\n" +
"							</p>\n" +
"						</article>\n" +
"                                        -->\n" +
"					<!-- Pagination -->\n" +
"					<!-- 	<div class=\"pagination\">\n" +
"							<a href=\"#\" class=\"button previous\">Previous Page</a>\n" +
"							<div class=\"pages\">\n" +
"								<a href=\"#\" class=\"active\">1</a>\n" +
"								<a href=\"#\">2</a>\n" +
"								<a href=\"#\">3</a>\n" +
"								<a href=\"#\">4</a>\n" +
"								<span>&hellip;</span>\n" +
"								<a href=\"#\">20</a>\n" +
"							</div>\n" +
"							<a href=\"#\" class=\"button next\">Next Page</a>\n" +
"						</div>\n" +
"                            -->\n" +
"\n" +
"				</div>\n" +
"			</div>");
          
      
            }
    
}
 