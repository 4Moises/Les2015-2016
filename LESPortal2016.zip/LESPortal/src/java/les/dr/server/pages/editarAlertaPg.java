/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package les.dr.server.pages;

import java.io.PrintWriter;
import java.util.List;
import les.dr.dao.Alerta;
import les.dr.dao.Alertas;

/**
 *
 * @author Utilizador
 */
public class editarAlertaPg extends Page {
    int idA;

    public editarAlertaPg(PrintWriter o) {
        super(o);
    }

    public editarAlertaPg(PrintWriter out, int id) {
        super(out);
        idA=id;
    }

    
     protected void genCSS(){
         printTab(); out.println("<link href=\"styles.css\" rel=\"stylesheet\">\n" +
"        <link rel=\"stylesheet\" type=\"text/css\" href=\"logincss.css\" />\n"+" <link rel=\"stylesheet\" href=\"http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css\">");
    }
      protected void genScript(){
          printTab(); out.println(" <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js\"></script>\n" +
"        <script src=\"http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js\"></script>\n"+
                  "<script src=\"assets/js/jscapch.js\"></script>");
      }

    @Override
    protected void genTitle() {
     printTab(); out.println(" <title>Gestão de Utilizadores</title>");
    }

    @Override
    protected void genBody() {
        out.println("<Body>");
           tab++;
           tab--;
            Alertas as = new Alertas();
       
        List<Alerta> la = as.list_a(idA);
        tab++;
        for (Alerta a : la){
         printTab(); out.println(" <div class=\"container\">\n" +
"            <div class=\"jumbotron\">\n" +
"                <h2><img src=\"images/DRE.png\" alt=\"\" /></h2> \n" +
"            </div>\n" +
"\n" +
"            <nav class=\"navbar navbar-default\">\n" +
"               \n" +
"\n" +
"            </nav>\n" +
"            <!-- REGISTRATION FORM -->\n" +
"            <div class=\"panel panel-default\">\n" +
"                <div class=\"panel-heading\">Registar</div>\n" +
"                <div class=\"panel-body\">    \n" +
"                    <form class=\"form-horizontal\" role=\"form\" action=\"updateAlerta\" method=\"post\">\n" +
"                        \n" +
"                        <div class=\"form-group\">\n" +

"                            <div class=\"col-sm-10\">\n" +
"                                <input  type=\"hidden\" class=\"form-control\" id=\"id_alerta\" name=\"id_alerta\" value="+a.getId_alerta()+">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"nome\">Nome:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"name\" class=\"form-control\" id=\"nome\" name=\"nome\" value="+a.getNome()+">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"emaill\">Email:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"email\" class=\"form-control\" id=\"emaill\" name=\"emaill\" value="+a.getEmaill()+">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        \n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"discricao\">Discricao:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"text\" class=\"form-control\" id=\"discricao\" name=\"discricao\" value="+a.getDescricao()+">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"estado\">Estado:</label>\n" +
"                            \n" +
"                                 <div class=\"col-sm-10\">          \n" +
"                                            <input type=\"radio\" name=\"estado\" value='1'> Activo\n" +
"                                            <input type=\"radio\" name=\"estado\" value='0'> Desatico\n" +
"                                        </div>\n" +
"                            </div>\n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"data\">Data:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"date\" class=\"form-control\" id=\"data\" name=\"data\" value="+a.getData()+">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"nota\">Nota:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"text\" class=\"form-control\" id=\"nota\" name=\"nota\" value="+a.getNota()+">\n" +
"                            </div>\n" +
"                        </div>\n" +
     "            <div class=\"form-group\">\n" +
                          
"                            <div class=\"col-sm-10\">          \n" +
"                                <input  type=\"hidden\" class=\"form-control\" id=\"on\" name=\"on\" value="+a.getOn()+">\n" +
"                            </div>\n" +
"                        </div>\n" +

"                        <div class=\"form-group\">\n" +
                       
"                            <div class=\"col-sm-10\">          \n" +
"                                <input  type=\"hidden\" class=\"form-control\" id=\"assunto\" name=\"assunto\" value="+a.getAssunto()+">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        <div class=\"form-group\">\n" +
                           
"                            <div class=\"col-sm-10\">          \n" +
"                                <input  class=\"form-control\"type=\"hidden\" id=\"email\" name=\"email\" value="+a.getEmail()+">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                       <!-- <div>\n" +
"                        <span id=\"captcha\"></span>\n" +
"                        <div >\n" +
"	                <input type=\"text\" name=\"captcha\" class=\"captcha\" maxlength=\"4\" size=\"4\" placeholder=\"Enter captcha code\" tabindex=3 />\n" +
"                         </div>\n" +
"                        </div>-->\n" +
"                     \n" +
"                        <div class=\"form-group\">        \n" +
"                            <div class=\"col-sm-offset-2 col-sm-10\">\n" +
"                                <button type=\"submit\" class=\"btn btn-default\" name=\"Submeter\">Editar</button>\n" +
"                            </div>\n" +
"                        </div>\n" +
"<ul id=\"copyright\">\n" +
"						<li>&copy; LesCompany.</li><li>Design: <a href=\"http://html5up.net\">Les 2016</a></li>\n" +
"					</ul>\n" +
"                    </form>\n" +
"                </div>\n" +
"            </div>\n" +
"\n" +
"        </div>");
        }
    
    }
    
}
