/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package les.dr.server.pages;

import java.io.PrintWriter;
import java.util.List;
import les.dr.dao.Alerta;
import les.dr.dao.Alertas;
import les.dr.dao.Notificacao;
import les.dr.dao.Notificacoes;

/**
 *
 * @author Utilizador
 */
public class NotificacaoPag extends OPages{
    private int _id_alerta;

    public NotificacaoPag(PrintWriter o) {
        super(o);
    }

    public NotificacaoPag(PrintWriter out, int id) {
        super(out);
        _id_alerta=id;
        
        }
 protected void genScript(){
      printTab(); out.println("<script src=\"assets/js/jscapch.js\"></script>");
 }
    @Override
    protected void genTitle() {
        printTab(); out.println("<title>DR - Notificacao Page</title>");
    }
    
    protected void genRightSide(){
         printTab(); out.println("<div id=\"content\">\n" +
"				<div class=\"inner\">\n" +
"\n" +
"					<!-- Post -->\n" +
"						<article class=\"box post post-excerpt\">\n" +
"                                                    <h2><img src=\"images/DRE.png\" alt=\"\" /></h2>\n" +
"							<header>\n" +
"								<!--\n" +
"									Note: Titles and subtitles will wrap automatically when necessary, so don't worry\n" +
"									if they get too long. You can also remove the <p> entirely if you don't\n" +
"									need a subtitle.\n" +
"								-->\n" +
"								\n" +
"								<!--<p>A free, fully responsive HTML5 site template by HTML5 UP</p>-->\n" +
"							</header>\n" +
"							<div class=\"info\">\n" +
"								<!--\n" +
"									Note: The date should be formatted exactly as it's shown below. In particular, the\n" +
"									\"least significant\" characters of the month should be encapsulated in a <span>\n" +
"									element to denote what gets dropped in 1200px mode (eg. the \"uary\" in \"January\").\n" +
"									Oh, and if you don't need a date for a particular page or post you can simply delete\n" +
"									the entire \"date\" element.\n" +
"\n" +
"								-->\n" +
"								<!--<span class=\"date\"><span class=\"month\">Jul<span>y</span></span> <span class=\"day\">14</span><span class=\"year\">, 2014</span></span>-->\n" +
"								<!--\n" +
"									Note: You can change the number of list items in \"stats\" to whatever you want.\n" +
"								-->\n" +
"								<!--<ul class=\"stats\">\n" +
"									<li><a href=\"#\" class=\"icon fa-comment\">16</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-heart\">32</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-twitter\">64</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-facebook\">128</a></li>\n" +
"								</ul>-->\n" +
"							</div>\n" +
"							 <div class=\"container\">\n" +
"                                                             <h2><i class=\"fa fa-files-o\"></i>Notificação</h2> \n" +
"                                                             \n" +
"                                                              <br>\n" +
"                                                             <br>\n" +
"                                                             \n" +
"                                                             \n" +
"             <div class=\"table-responsive mailbox-messages\">\n" +
"                <table class=\"table table-hover table-striped\">\n" +
"                  <tbody>");
   
        Notificacoes ns = new Notificacoes();
       // List<Notificacao> ln = ns.list();
        List<Notificacao> ln = ns.list_n(_id_alerta);
        tab++;
        for (Notificacao n : ln){
            printTab(); out.println("<tr>");
           printTab(); out.println("  <td><input type=\"checkbox\"></td>");
            printTab(); out.println(" <td class=\"mailbox-star\"><a href=\"#\"><i class=\"fa fa-star text-yellow\"></i></a></td>");
            // printTab(); out.println("  <td class=\"mailbox-name\"><a href=\"read-mail.html\">"+a.getNome()+"</a></td>");
            printTab(); out.println("  <td class=\"mailbox-name\"><span id=\"tipo_alert\" name="+n.getId_notificacao()+">"+n.getDiscricao()+"</span></td>");
             printTab(); out.println(" <td class=\"mailbox-subject\"><b>"+n.getLink()+"</b>\n" +
"                    <small> <i class=\" fa fa-clock-o\"></i>"+n.getData()+"</small>\n" +
//"                    <button type=\"button\" class=\"btn btn-default btn-sm\" ><a id='tipo' name="+n.getId_notificacao()+" href='removerNotificacao?tipo="+n.getId_notificacao()+"'><i class=\"fa fa-trash-o\"></i></a></button>\n" +
"                   <a id='tipo' name="+n.getId_notificacao()+" href='removerNotificacao?tipo="+n.getId_notificacao()+"'><i class=\"fa fa-trash-o\"></i></a>\n" +
                     "                    \n" +
"                    </td>");
             printTab(); out.println("  </tr>");
        }
        printTab(); out.println("</tbody>\n" +
"                </table>\n" +
"                <!-- /.table -->\n" +
"              </div>\n" +
"              \n" +
"              \n" +
"\n" +
"        </div>\n" +
"						</article>\n" +
"\n" +
"					<!-- Post -->\n" +
"					<!--	<article class=\"box post post-excerpt\">\n" +
"							<header>\n" +
"								<h2><a href=\"#\">Lorem ipsum dolor sit amet</a></h2>\n" +
"								<p>Feugiat interdum sed commodo ipsum consequat dolor nullam metus</p>\n" +
"							</header>\n" +
"							<div class=\"info\">\n" +
"								<span class=\"date\"><span class=\"month\">Jul<span>y</span></span> <span class=\"day\">8</span><span class=\"year\">, 2014</span></span>\n" +
"								<ul class=\"stats\">\n" +
"									<li><a href=\"#\" class=\"icon fa-comment\">16</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-heart\">32</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-twitter\">64</a></li>\n" +
"									<li><a href=\"#\" class=\"icon fa-facebook\">128</a></li>\n" +
"								</ul>\n" +
"							</div>\n" +
"							<a href=\"#\" class=\"image featured\"><img src=\"images/pic02.jpg\" alt=\"\" /></a>\n" +
"							<p>\n" +
"								Quisque vel sapien sit amet tellus elementum ultricies. Nunc vel orci turpis. Donec id malesuada metus.\n" +
"								Nunc nulla velit, fermentum quis interdum quis, tate etiam commodo lorem ipsum dolor sit amet dolore.\n" +
"								Quisque vel sapien sit amet tellus elementum ultricies. Nunc vel orci turpis. Donec id malesuada metus.\n" +
"								Nunc nulla velit, fermentum quis interdum quis, convallis eu sapien. Integer sed ipsum ante.\n" +
"							</p>\n" +
"						</article>\n" +
"                                        -->\n" +
"					<!-- Pagination -->\n" +
"					<!-- 	<div class=\"pagination\">\n" +
"							<a href=\"#\" class=\"button previous\">Previous Page</a>\n" +
"							<div class=\"pages\">\n" +
"								<a href=\"#\" class=\"active\">1</a>\n" +
"								<a href=\"#\">2</a>\n" +
"								<a href=\"#\">3</a>\n" +
"								<a href=\"#\">4</a>\n" +
"								<span>&hellip;</span>\n" +
"								<a href=\"#\">20</a>\n" +
"							</div>\n" +
"							<a href=\"#\" class=\"button next\">Next Page</a>\n" +
"						</div>\n" +
"                            -->\n" +
"\n" +
"				</div>\n" +
"			</div>");
            }
    }     
    

