/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package les.dr.server.pages;

import java.io.PrintWriter;

/**
 *
 * @author rodma
 */
public class IndexPage_1 extends OPage {

    public IndexPage_1(PrintWriter o) {
        super(o);
    }

    

    
    
    @Override
    protected void genTitle() {
          printTab(); out.println("<title>DR - Login Page</title>");
        }
     protected void genRightSide(){
          printTab(); out.println(""
                  + "<!-- Content -->\n" +
"			<div id=\"content\">\n" +
"				<div class=\"inner\">\n" +
"\n" +
"					<!-- Post -->\n" +
"						<article class=\"box post post-excerpt\">\n" +
"							<header>\n" +

"                                                            \n" +
"								<h2><a href=\"#\">Welcome to Diário da Republica</a></h2>\n" +
"								<!--<p>A free, fully responsive HTML5 site template by HTML5 UP</p>-->\n" +
"							</header>\n" +
"							<div class=\"info\">\n" +
"							</div>\n" +
"							<a href=\"#\" class=\"image featured\"><img src=\"images/Diario_da_republica.jpg\" alt=\"\" /></a>\n" +
"							\n" +
"						</article>\n" +
"				</div>\n" +
"			</div>\n" +
"\n" +
"		<!-- Sidebar -->");
         
     }
}
