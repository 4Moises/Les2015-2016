/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package les.dr.server.pages;

import java.io.PrintWriter;

/**
 *
 * @author rodma
 */
public class AdicAdmin1 extends Page {

    public AdicAdmin1(PrintWriter o) {
        super(o);
    }
 protected void genCSS(){
        printTab(); out.println("<link rel=\"stylesheet\" href=\"http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css\">");
        printTab(); out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"logincss.css\" />");
    }
    
    @Override
    protected void genTitle() {
     printTab(); out.println("<title>DR</title>");
    }

    @Override
    protected void genBody() {
    
        out.println("<body>");
        tab++;
        printTab(); out.println(""
                + "<div class=\"container\">\n" +
"            <div class=\"jumbotron\">\n" +
"                <h2><img src=\"images/DRE.png\" alt=\"\" /></h2> \n" +
"            </div>\n" +
"\n" +
"            <nav class=\"navbar navbar-default\">\n" +
"               \n" +
"\n" +
"            </nav>\n" +
"            <!-- REGISTRATION FORM -->\n" +
"            <div class=\"panel panel-default\">\n" +
"                <div class=\"panel-heading\">Inserir Administrador</div>\n" +
"                <div class=\"panel-body\">    \n" +
"                    <form class=\"form-horizontal\" role=\"form\" action=\"adminV\" method=\"post\">\n" +
"                        \n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"nome\">Nome:</label>\n" +
"                            <div class=\"col-sm-10\">\n" +
"                                <input type=\"text\" class=\"form-control\" id=\"nome\" name=\"nome\" placeholder=\"Introduza o nome\">\n" +
"                            </div>\n" +
"                        </div>\n" +                
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"email\">Email:</label>\n" +
"                            <div class=\"col-sm-10\">\n" +
"                                <input type=\"email\" class=\"form-control\" id=\"email\" name=\"email\" placeholder=\"Introduza o email\">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"password\">Password:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"password\" class=\"form-control\" id=\"password\" name=\"password\" placeholder=\"Introduza a password\">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        <div class=\"form-group\">\n" +
"                            <label class=\"control-label col-sm-2\" for=\"pwd\">Confir. da Password:</label>\n" +
"                            <div class=\"col-sm-10\">          \n" +
"                                <input type=\"password\" class=\"form-control\" id=\"confirmacaoPassword\" name=\"confirmacaoPassword\" placeholder=\"Introduza a password\">\n" +
"                            </div>\n" +
"                        </div>\n" +
"                        \n" +
"                     \n" +
"                        <div class=\"form-group\">        \n" +
"                            <div class=\"col-sm-offset-2 col-sm-10\">\n" +
"                                <button type=\"submit\" class=\"btn btn-default\" name=\"Submeter\" onclick=\"\">Submit</button>\n" +
"                            </div>\n" +
"                        </div>\n"+
                "<script>\n" +
"                            function sc(){\n" +
"                                window.alert(\"Adicionado com sucesso\");\n" +
"                            }\n" +
"                        </script>" +
"<ul id=\"copyright\">\n" +
"						<li>&copy; LesCompany.</li><li>Design: <a href=\"http://html5up.net\">Les 2016</a></li>\n" +
"					</ul>\n" +
"                    </form>\n" +
"                </div>\n" +
"            </div>\n" +
"\n" +
"        </div>");
        tab--;
        out.println("</body>");
    }
    
}
