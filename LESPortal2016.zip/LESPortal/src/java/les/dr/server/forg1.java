/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package les.dr.server;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import java.util.UUID;
import javax.mail.AuthenticationFailedException;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import les.dr.dao.Infrecpass;
import les.dr.dao.Infrecpasses;
import les.dr.dao.Utilizador;
import les.dr.dao.Utilizadores;
import les.dr.server.pages.ForgPage;
import les.dr.server.pages.LoginPage;
import les.dr.server.pages.Page;

/**
 *
 * @author rodma
 */
@WebServlet(name = "forg1", urlPatterns = {"/forg1"})
public class forg1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String email= request.getParameter("email");
        Utilizadores us = new Utilizadores();
        Utilizador u = new Utilizador(email);
        Utilizador u3=us.find(u);
        if(u3!=null){
          /*  java.util.Date dt = new java.util.Date();
            java.sql.Date sqldt = new java.sql.Date(dt.getTime());
            Infrecpasses is = new Infrecpasses();
            String n = UUID.randomUUID().toString();
            Infrecpass i = new Infrecpass(email,n,sqldt);
            if(is.add(i)){
                try (PrintWriter out = response.getWriter()) {
                    Page pag = new LoginPage(out);
                    pag.genPage();
                }
            }*/
            String pwd = u3.getPassword();
            Email email_send = new Email(); // construir objecto Email;
        
            String to[] = {email};// Para enviar multiplos emails, separe os endereços por ","
            String assunto = "Password";
            String corpo_msg = "O seu password é" + pwd;

            // Invocar metodo "sendFromGMail" do class "Email.java"
            email_send.sendFromGMail("rickyleaks91@gmail.com", "ipbssi2016", to, assunto, corpo_msg);
            try (PrintWriter out = response.getWriter()) {
            Page pag = new LoginPage(out);
            pag.genPage();
            }
    
        }else{
            try (PrintWriter out = response.getWriter()) {
            Page pag = new ForgPage(out, "Email invalido!");
            pag.genPage();
            }
        }
    }
     

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
