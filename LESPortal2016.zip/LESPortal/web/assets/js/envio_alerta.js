function enviaralerta() {
		// var tipo_alerta = $("#tipo_alerta").val();
		// var tipo_alerta = $("span[name=tipo_alert]").val();
                // var tipo_alerta = $(this).attr("name");
                
                alert ("external JS.");
                // window.location.href="http://www.facebook.com";
                //window.location="NotificacaoPag?id_alerta="+tipo_alerta;
		/* $.ajax({
			type: "POST",
			url: "notificacao_alerta",
			dataType: "json",
			data: "{'tipo_alerta':" + tipo_alerta+"}"
		}); */
	}